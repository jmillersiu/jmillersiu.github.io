---
layout: page
title: About Jeff
permalink: /about/
---

Jeff Miller is an IT Professional living in Makanda, Illinois with his wife
Jennifer and 3 children, Drew, Robby, and Jenna.
